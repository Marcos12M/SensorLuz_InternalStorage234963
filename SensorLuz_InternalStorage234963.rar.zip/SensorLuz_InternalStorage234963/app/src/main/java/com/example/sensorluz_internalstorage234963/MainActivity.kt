package com.example.sensorluz_internalstorage234963

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import java.io.*

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var lightSensor: Sensor? = null

    private var maxLight: Float = Float.MIN_VALUE
    private var minLight: Float = Float.MAX_VALUE

    private lateinit var txtMayorLuz: TextView
    private lateinit var txtMenorLuz: TextView
    private lateinit var txtLuzActual: TextView
    private lateinit var txtEstado: TextView
    private lateinit var btnGuardar: Button
    private lateinit var imageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicialización de vistas
        txtMayorLuz = findViewById(R.id.txtMayorLuz)
        txtMenorLuz = findViewById(R.id.txtMenorLuz)
        txtLuzActual = findViewById(R.id.txtLuzActual)
        txtEstado = findViewById(R.id.txtEstado)
        btnGuardar = findViewById(R.id.btnGuardar)
        imageView = findViewById(R.id.imageView)

        // Inicialización del sensor de luz
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)

        // Manejador de clics en el botón Guardar
        btnGuardar.setOnClickListener {
            saveCurrentLight()
        }
    }

    override fun onResume() {
        super.onResume()
        lightSensor?.let { sensor ->
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // No se usa en este ejemplo
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            if (event.sensor.type == Sensor.TYPE_LIGHT) {
                val currentLight = event.values[0]
                txtLuzActual.text = "Luz actual: $currentLight ←"

                // Actualizar máximo y mínimo
                if (currentLight > maxLight) {
                    maxLight = currentLight
                    txtMayorLuz.text = "Máxima luz detectada: $maxLight ↑"
                }
                if (currentLight < minLight) {
                    minLight = currentLight
                    txtMenorLuz.text = "Mínima luz detectada: $minLight ↓"
                }
            }
        }
    }

    private fun saveCurrentLight() {
        val filename = "light_data.txt"
        val fileContents = "Máxima luz detectada: $maxLight ↑\n" +
                "Mínima luz detectada: $minLight ↓"

        try {
            openFileOutput(filename, Context.MODE_PRIVATE).use {
                it.write(fileContents.toByteArray())
            }
            txtEstado.text = "Datos guardados!"
        } catch (e: IOException) {
            txtEstado.text = "Error al guardar los datos x.x"
            e.printStackTrace()
        }
    }
}